from django.apps import AppConfig
default_app_config = 'slides.SlideConfig'


class SlideConfig(AppConfig):
    name = 'slides'
    verbose_name = 'Слайдер на главной'

